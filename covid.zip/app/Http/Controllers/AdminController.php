<?php

namespace App\Http\Controllers;

use App\Casenum;
use App\Death;
use App\Recovered;
use App\Symp;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{



}
