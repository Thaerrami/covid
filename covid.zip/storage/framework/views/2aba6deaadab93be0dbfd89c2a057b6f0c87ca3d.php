

<?php $__env->startSection('content'); ?>

<div class="col-md-9 personal-info">
  <h3>Personal info</h3>
  
  <form class="form-horizontal" role="form" action="<?php echo e(route('doc.updatedata')); ?>" method="POST"  >
      <?php echo csrf_field(); ?>
      <div class="form-group">
          <label class="col-lg-3 control-label ">title :</label>
          <div class="col-lg-8">
            <input class="form-control" type="text" name='title' value="<?php echo e($title); ?>">
          </div>
      </div>

      <div class="form-group">
          <label class="col-lg-3 control-label">Description</label>
          <div class="col-lg-8">
              <textarea class="form-control" name='description' value="<?php echo e($disc); ?>"></textarea>
          </div>
      </div>

        <hr>

      <div class="form-group">
      <label class="col-lg-3 control-label">Full name:</label>
      <div class="col-lg-8">
        <input class="form-control" type="text" name='username' value="<?php echo e($name); ?>">
      </div>
    </div>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Email:</label>
      <div class="col-lg-8">
        <input class="form-control" type="text" name='email' value="<?php echo e($email); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Start Work At</label>
      <div class="col-lg-8">
        <div class="ui-select">
         <input class="form-control" type="time" value=<?php echo e($end??'08:00'); ?> name="StartAt" >
        </div>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">End Work At</label>
      <div class="col-lg-8">
        <div class="ui-select">
         <input class="form-control" type="time" name="EndAt" value=<?php echo e($start??'21:00'); ?> >
        </div>
      </div>
    </div>

    

    <div class="form-group">
      <label class="col-lg-3 control-label">country:</label>
      <div class="col-lg-8">
        <input class="form-control" type="text"  list="country" name='country' value=<?php echo e($country??'null'); ?> required  id="browser">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">city:</label>
      <div class="col-lg-8">
        <input class="form-control"  type="text" name="city" value=<?php echo e($city??'null'); ?>  />
      </div>
    </div>


    <div class="form-group">
      <label class="col-lg-3 control-label">phone:</label>
      <div class="col-lg-8">
        <input class="form-control"  type="text" name="phone" value=<?php echo e($phone??'null'); ?>  />
      </div>
    </div>


    
    


    <datalist id="country">
      <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item['name']); ?>"> 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </datalist>

<input type="submit" name="submit" class="btn btn-primary m-3">
  </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('doctor.edittemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/doctor\editdata.blade.php ENDPATH**/ ?>