


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="w-100">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-light border m-4 p-3 w-100 rounded position-relative"><span class="position-absolute bg-dark text-light p-1 rounded" style="top:-15px;right:20px"><?php echo e($item['date']); ?></span><?php echo e($item['report']); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/myreport.blade.php ENDPATH**/ ?>