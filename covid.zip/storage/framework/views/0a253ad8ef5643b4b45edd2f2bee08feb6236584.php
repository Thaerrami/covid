

<?php $__env->startSection('content'); ?>

<div class="col-md-9 personal-info">
  <h3>Personal info</h3>
  
  <form class="form-horizontal" id="submit" role="form" method="POST" autocomplete="off" >
      <?php echo csrf_field(); ?>

      <div class="form-group">
          <label class="col-lg-3 control-label ">title :</label>
          <div class="col-lg-8">
            <input class="form-control" type="text" name='title' id="title" value="<?php echo e($title); ?>">
          </div>
      </div>

      <div class="form-group">
          <label class="col-lg-3 control-label">Description</label>
          <div class="col-lg-8">
              <textarea class="form-control" name='description' id="description" ><?php echo e($desc); ?></textarea>
          </div>
      </div>

        <hr>

      <div class="form-group">
      <label class="col-lg-3 control-label">Full name:</label>
      <div class="col-lg-8">
        <input class="form-control" type="text" id="username" name='username' value="<?php echo e($name); ?>">
      </div>
    </div>
    
    <div class="form-group">
      <label class="col-lg-3 control-label">Email:</label>
      <div class="col-lg-8">
        <input class="form-control" type="text" name='email' id="email" value="<?php echo e($email); ?>">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">Start Work At</label>
      <div class="col-lg-8">
        <div class="ui-select">
         <input class="form-control" type="time"  value="<?php echo e($end??'08:00'); ?>" name="StartAt" id="StartAt" >
        </div>
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">End Work At</label>
      <div class="col-lg-8">
        <div class="ui-select">
         <input class="form-control" type="time" name="EndAt" value="<?php echo e($start??'21:00'); ?>" id="EndAt" >
        </div>
      </div>
    </div>

    

    <div class="form-group">
      <label class="col-lg-3 control-label">country:</label>
      <div class="col-lg-8">
        <input class="form-control" type="text"  list="country" name='country' id="country"  value="<?php echo e($country??''); ?>" required  id="browser">
      </div>
    </div>

    <div class="form-group">
      <label class="col-lg-3 control-label">city:</label>
      <div class="col-lg-8">
        <input class="form-control"  type="text" name="city"  id="city" value="<?php echo e($city??''); ?>"  />
      </div>
    </div>


    <div class="form-group">
      <label class="col-lg-3 control-label">phone:</label>
      <div class="col-lg-8">
        <input class="form-control"  type="text" name="phone" id="phone" value="<?php echo e($phone??''); ?>"  />
      </div>
    </div>


    
    


    <datalist id="country">
      <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($item['name']); ?>"> 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </datalist>

<input type="submit" name="submit" class="btn btn-primary m-3 save-data">
  </form>
</div>




<script>

  $("#submit").on('submit',(e)=>{
    e.preventDefault();    

    var datatosend=[];
    var arr={};

    var title =$('#title').val();
    var description =$('#description').val();
    var username =$('#username').val();
    var email =$('#email').val();
    var StartAt =$('#StartAt').val();
    var EndAt =$('#EndAt').val();
    var country =$('#country').val();
    var city =$('#city').val();
    var phone =$('#phone').val();  
    
       $.ajax({
         method:'POST',
         url:"<?php echo e(route('doc.updatedata')); ?>",
         data:{
            _token: '<?php echo e(csrf_token()); ?>',
            title:title,
            description:description,
            email:email,
            StartAt:StartAt,
            EndAt:EndAt,
            country:country,
            city:city,
            phone:phone
         },
         success:(data)=>{
           console.log(data)
         },
         error:(error)=>{
           console.log(error)
         }
       }
     )
  
     
    });
       
      </script>
  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('doctor.edittemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/doctor/editdata.blade.php ENDPATH**/ ?>