

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href=<?php echo e(asset('css/checkbox.css')); ?>>
<div class="container p-2 " style="background-image: linear-gradient(to right ,#0044ee88,#0e444499)">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center mb-2 font-weight-bolder p-2 bg-secondary text-white">
              <p  style="font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; font-size:30px">Date to day  { <?php echo e(date('Y-m-d')); ?> }</p>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript">
    $("document").ready(()=>{
        
        var symps=[];
        var url='/doc/docsavesymp';
        var dayreport='';
        var id;
        var sympdeg=[];

        $( "#form" ).submit(function( event ) {
            event.preventDefault();

            $('input:checked').each(function(){
                sympdeg.push($(this).data('sympdeg'));
            });

            dayreport=$("textarea[name='dayreport']").val() ??'nothing to day';
            id=$('#id').val();

            $("input:checked").each(function(){ 
                symps.push(this.value);
            });

            sympdeg=Math.max(...sympdeg);
            symps=JSON.stringify(symps);
            

            $.ajax({
        method:'POST',
        url:url,
        data:{
            _token:'<?php echo e(csrf_token()); ?>',
            symps:symps,
            sympdeg:sympdeg,
            dayreport:dayreport,
            id:id
        },
        success:(data)=>{
            alert(data);
            window.history.back();
        },
        error:(data)=>{
            console.log(data)
        }
    })    

            })

        
    })

  

    

</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/symp/docfillsymp.blade.php ENDPATH**/ ?>