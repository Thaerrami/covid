

<?php $__env->startSection('content'); ?>


<!------ Include the above in your HEAD tag ---------->

<?php $__env->startPush('head'); ?>
<!-- Styles -->
<link rel="stylesheet" href=<?php echo e(asset('css/phome.css')); ?>>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php $__env->stopPush(); ?>


<div class="container emp-profile pcb mt-5 bg-white p-3 " style='border-radius:20px'>
            <form method="post">
                <div class="row ">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <img  class='docimage'
                            src="<?php echo e(asset( $image!==null? "storage/$image":'mp/anon.png')); ?>" alt="no image"/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5>
                                        <?php echo e($name); ?>

                                    </h5>
                                    <p class="proile-rating">status : <span><?php echo e($status); ?></span></p>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">State info</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                   
                </div>
                <div class="row mt-3">

                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-8">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Name</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($name); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($email); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Phone</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($phone); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>country</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($country); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>city</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($city); ?></p>
                                            </div>
                                        </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>status</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($status); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>current state</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($current); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>logged in</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($start); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Birth Of Date</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($bof); ?></p>
                                            </div>
                                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form> 
             
                 <hr style="border:1px solid rgb(112, 112, 112) ; border-radius:50%">
                
                 <h2 class="text-center m-5 rounded bg-info p-2 text-white"> Patient Reports 
                     <img src="https://img.icons8.com/nolan/64/business-report.png"/>
                </h2>

               

                <?php if(isset($finalreport)): ?>
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Date</th>
                        <th scope="col">report</th>
                      </tr>
                    </thead>
                    <tbody>
                     <tr>
                        <td><?php echo e($finalreport['date']); ?></td>
                        <td><?php echo e($finalreport['recoverreport']??$finalreport['deathreport']); ?></td>
                      </tr>   
                    </tbody>
                  </table>
                <?php endif; ?>

                 <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Date</th>
                        <th scope="col">report</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                     <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($item['date']); ?></td>
                        <td><?php echo e($item['report']); ?></td>
                      </tr>   
                     
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

        </div>

        <?php $__env->startPush('headhome'); ?>
<!-- Styles -->
<!-- Scripts -->
<script src="<?php echo e(asset('js/updateuser.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/admin/showpat.blade.php ENDPATH**/ ?>