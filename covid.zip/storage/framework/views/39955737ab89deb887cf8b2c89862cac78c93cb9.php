

<?php $__env->startSection('content'); ?>

<form  method="POST" id="submit"> 
    <?php echo csrf_field(); ?>
<div class="row">                    
    <div class="col">
      <div class="form-group">
        <label>Birth Of Date</label>
        <input class="form-control" required type="date" id="birthdate" name="birthdate" placeholder=<?php echo e(Auth::user()->birthdate); ?> value=<?php echo e(Auth::user()->birthdate); ?> >
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col d-flex justify-content-end">
      <button class="btn btn-primary" type="submit">Save Changes</button>
    </div>
  </div>
</form>


<script>

  $("#submit").on('submit',(e)=>{
    e.preventDefault();
  
    var birthdate = $('#birthdate').val();

    
       $.ajax({
         method:'POST',
         url:"./edituserprofile",
         data:{
            _token: '<?php echo e(csrf_token()); ?>',
            birthdate:birthdate,
         },
         success:(data)=>{
           alert('birth of date successfuly');
         },
         error:(error)=>{
           console.log(error)
         }
       }
     )
     
    });
       
      </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.editprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/editbirthdate.blade.php ENDPATH**/ ?>