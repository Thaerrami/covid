

<?php $__env->startSection('content'); ?>


<!------ Include the above in your HEAD tag ---------->

<?php $__env->startPush('head'); ?>
<!-- Styles -->
<link rel="stylesheet" href=<?php echo e(asset('css/phome.css')); ?>>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php $__env->stopPush(); ?>


<div class="jumbotron bg-primary text-white m-2">
    <div class="container text-center ">
      <h1><?php echo e($uname); ?></h1>      
      <p>title : <?php echo e($title); ?></p>
    </div>
    <img width="200" class='docimage' src="<?php echo e(asset( $image!==''? "storage/$image":'mp/anon.png')); ?>"  alt="no image">
    <div class="row">
        <h1 class="text-center w-100 jumbotron bg-primary">
            Description
        </h1>
        <div class="text-center w-75 m-auto ">
          <?php echo e($desc ?? ''); ?>

                  </div>
        
      </div> 
</div>
    
  <div class="container-fluid bg-3 text-center">    
    <h3>data</h3><br>
    <div class="row">
      <div class="col-sm-3">
        <p>phone</p>
        <?php echo e($uphone); ?>

      </div>
      <div class="col-sm-3"> 
        <p>Email</p>
        <?php echo e($uemail); ?>

    </div>
      <div class="col-sm-3"> 
        <p>Number Of Patient</p>
       <?php echo e($nofp); ?>

    </div>
      <div class="col-sm-3">
        <p>Country/City</p>
        <?php echo e($country??'null'); ?>/<?php echo e($city??'null'); ?>

    </div>
    </div>
  </div><br>
  <hr>


  <div class="container-fluid bg-3 text-center">    

    <div class="row">
      <div class="col-sm-3">
        <p>start-end work</p>
       ( <?php echo e($start??'null'); ?>-<?php echo e($end??'null'); ?> ) work
      </div>
      
     
    </div>
  </div><br>
  
  <footer class="container-fluid text-center mt-5">
    <p>Footer Text</p>
  </footer>
  
        <?php $__env->startPush('headhome'); ?>
<!-- Styles -->
<!-- Scripts -->
<script src="<?php echo e(asset('js/updateuser.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/doc.blade.php ENDPATH**/ ?>