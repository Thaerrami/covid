<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
        <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/allpatient.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm" style="z-index: 1000">
            <div class="container p-0 m-0">
                <a class="navbar-brand" href="<?php echo e(url('/admin')); ?>">
                    <i class="fa fa-home" aria-hidden="true">Home</i>
                    <div class="gradient-border" id="box"><img style="width:50px;height:50px;border-radius:50%;border:2px solid yellow" src=<?php echo e(asset(Auth::user()->image != ''? "storage/".Auth::user()->image:'mp/anon.png')); ?> />
                        
                    
                </a>
                
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(Auth::check()): ?>
                    <a class="navbar-brand select" href="<?php echo e(url('admin/showuser')); ?>">
                        Patients
                    </a>
                    <br>
                    <a class="navbar-brand select" href="<?php echo e(route('admin.doctors')); ?>">
                        Doctors
                    </a>
                    <br>
                    <a class="navbar-brand select" href="<?php echo e(route('admin.editprofileview')); ?>">
                        edit profile
                    </a>
                    <br>
                    <a class="navbar-brand select" href="<?php echo e(url('admin/sympcontroll')); ?>">
                        Spymptoms controll
                    </a>
                    <?php endif; ?>
                    <ul class="navbar-nav mr-auto">

                    </ul>
                    <li class="list-group"> <a class="navbar-brand select text-secondary" href="<?php echo e(route('help')); ?>" style="font-size: 10px"> <img src="<?php echo e(asset('mp/help.svg')); ?>" width="30" alt=""> Help &support</a></li>
               
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('admin.login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
    </div>

</body>
</html>
<?php /**PATH C:\xamp\php\www\covid\resources\views/layouts/adminapp.blade.php ENDPATH**/ ?>