<?php $__env->startSection('content'); ?>


<!------ Include the above in your HEAD tag ---------->

<?php $__env->startPush('head'); ?>
<!-- Styles -->
<link rel="stylesheet" href=<?php echo e(asset('css/phome.css')); ?>>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php $__env->stopPush(); ?>


<div class="container emp-profile pcb">
            <form method="post">
                <div class="row bg-light">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <?php if(isset($image)): ?>
                            <img class="pimage" src="storage/<?php echo e($image); ?>" alt="no image" />
                            <?php else: ?>
                            <img style="width:270px; height:270px" src=<?php echo e(asset('mp/anon.png')); ?> alt=""/>
                            <?php endif; ?>
                            
                            
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5>
                                        <?php echo e($name); ?>

                                    </h5>
                                    <p class="proile-rating">status : <span><?php echo e($status); ?></span></p>

                                    <p class="proile-rating">(( case / recovered / dieth )) : <span><?php echo e($current); ?></span></p>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">State info</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a type="submit" class="profile-edit-btn" style='text-decoration:none' href='/pne' name="btnAddMore" >Edit Profile</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <?php if($current==='Case'): ?>
                        <?php if($filled): ?>
                        
                            <div class='text-center'>
                                <h1><img id="editableimage2" src="<?php echo e(asset('mp/inserted.gif')); ?>" width="300px" alt="sending a hug gifs get the best gif on giphy"/></h1>
                                <h4>Data insterted to day</h4>
                            </div>
                            
                        <?php else: ?>
                        <a class='text-center btn btn-primary ml-5 mt-5' style='margin:auto; text-decoration:none;;margin-top:20px' href="/symptoday"><h3>Fill data Now</h3></a>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-8">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Name</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($name); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-6">
                                                <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Phone</label>
                                            </div>
                                            <div class="col-md-6">
                                                <a href="tel:<?php echo e($phone); ?>"><?php echo e($phone); ?></a>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>country</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($country); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>city</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($city); ?></p>
                                            </div>
                                        </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>status</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($status); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>current state</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($current); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>logged in</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($start); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Birth Of Date</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($bof); ?></p>
                                            </div>
                                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form> 
             
                 
        </div>

        <?php $__env->startPush('headhome'); ?>
<!-- Styles -->
<!-- Scripts -->
<script src="<?php echo e(asset('js/updateuser.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/home.blade.php ENDPATH**/ ?>