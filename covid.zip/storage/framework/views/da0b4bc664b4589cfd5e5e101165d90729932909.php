


<?php $__env->startSection('patient.content'); ?>
<form action="">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col">
          <div class="form-group">
            <label>country</label>
            <input class="form-control" type="text" placeholder=<?php echo e(Auth::user()->country); ?>>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <div class="form-group">
            <label>city</label>
            <input class="form-control" type="text" placeholder=<?php echo e(Auth::user()->city); ?>>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col d-flex justify-content-end">
          <button class="btn btn-primary" type="submit">Save Changes</button>
        </div>
      </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('editprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/pplace.blade.php ENDPATH**/ ?>