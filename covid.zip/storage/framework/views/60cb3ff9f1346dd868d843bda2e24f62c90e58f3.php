
<?php $__env->startSection('content'); ?>
<div class="bg-light p-3 d-flex justify-content-around">
    <span class="btn btn-secondary text-decoration-none text-black-50" style="font-size: 30px" onclick="window.history.back()"> &#x2B98; </span>
    <span class="btn "><a href="/" class='text-black-50'>home</a></span>
    <span class="btn "><a href="<?php echo e(route('help')); ?>" class='text-black-50'>help</a></span>
    <span class="btn "><a href="<?php echo e(route('about')); ?>" class='text-black-50'>about us </a></span>
</div>
    <div class="container">
        <?php echo $__env->yieldContent('helpshap'); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/help/helptemplate.blade.php ENDPATH**/ ?>