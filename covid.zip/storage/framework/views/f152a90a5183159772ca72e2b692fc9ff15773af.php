Hello <strong><?php echo e($name); ?></strong>,
<p><?php echo e($body); ?></p>
<div><a href="http://localhost:8000/">http://localhost:8000/</a></div><?php /**PATH C:\xamp\php\www\covid\resources\views/emails/mail.blade.php ENDPATH**/ ?>