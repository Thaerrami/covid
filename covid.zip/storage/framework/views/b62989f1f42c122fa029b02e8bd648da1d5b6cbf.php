
<?php $__env->startSection('helpshap'); ?>
   <h1 class="mt-2">Help</h1>
   <div class="container w-100 mt-5">
       <div class="row w-100">
           <form action="<?php echo e(route('helpquestion')); ?>" method="POST"  class="w-100">
            <?php echo csrf_field(); ?>
               <input required name='name' type="text" class="form-control mb-2" placeholder="enter your name" />
               <textarea required class="form-control" placeholder="enter message" name="message" id="" style="width: 100%;color:rgba(2, 202, 52, 0.746)" cols="30" rows="5" ></textarea>
               <button type="submit" class="btn  btn-success m-3 ">Send <img src="<?php echo e(asset('mp/send.svg')); ?>"  width=30 alt=""></button>
           </form>
       </div>
       <div class="row">
           <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="p-1 bg-info w-75 m-2 p-1 rounded">
           <div class="bg-white rounded w-25 p-1 mb-1"><?php echo e($item->name); ?></div>    
           <div class="bg-white rounded p-1"><?php echo e($item->message); ?></div>
        </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('help.helptemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/help/help.blade.php ENDPATH**/ ?>