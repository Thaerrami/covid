


<?php $__env->startSection('content'); ?>
<form  id="submit" method="POST">
    <?php echo csrf_field(); ?>

<div class="row">
    <div class="col">
      <div class="form-group">
        <label>Email</label>
        <input class="form-control" type="text" name='email' id="email"  required value=<?php echo e(Auth::user()->email); ?> placeholder=<?php echo e(Auth::user()->email); ?>>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col d-flex justify-content-end">
      <button class="btn btn-primary" type="submit">Save Changes</button>
    </div>
  </div>
</form>


<script>

  $("#submit").on('submit',(e)=>{
    e.preventDefault();
  
    var email = $('#email').val();

    
       $.ajax({
         method:'POST',
         url:"./edituserprofile",
         data:{
            _token: '<?php echo e(csrf_token()); ?>',
            email:email,
         },
         success:(data)=>{
           alert('email  successfuly updated');
         },
         error:(error)=>{
           console.log(error)
         }
       }
     )
     
    });
       
      </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.editprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/peditemail.blade.php ENDPATH**/ ?>