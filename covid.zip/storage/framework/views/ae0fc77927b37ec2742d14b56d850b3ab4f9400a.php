

<!------ Include the above in your HEAD tag ---------->
<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row">
            <div class="col-12 text-center">
                <form action="<?php echo e(route('doc.changestatus')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value=<?php echo e($patdata['id']); ?> name="id">
                    <label class="col-form-label bg-success border rounded p-2 mb-2 text-white" for="state">please enter the paitent status</label>
                    <select name="state" id="state" class="form-control">
                        <option class="text-center" value="1">recovered</option>
                        <option class="text-center" value="3">death</option>
                    </select>
                    <label class="col-form-label bg-success border rounded p-2 mb-2 mt-3 text-white" for="state">Write Finalization Report</label><br>
                    <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="btn btn-info text-white pl-4 pr-4 rounded  m-2 float-left">Suggestions</span>
                    <div class="bg-dark rounded w-100 d-inline-block p-2 "  >
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg"><?php echo e($patdata['name']); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg"><?php echo e($patdata['phone']); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg"><?php echo e($patdata['date']); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg"><?php echo e($patdata['email']); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg"><?php echo e($patdata['city']); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg"><?php echo e($patdata['country']); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg">starts at<?php echo e(date("d M Y", strtotime($patdata['created_at']))); ?></span>
                        <span  style="width: fit-content;word-wrap: none;word-wrap: wrap none;" class="bg-secondary  pl-4 pr-4 rounded text-white mt-2 sugg ">last update at <?php echo e(date("d M Y", strtotime($patdata['updated_at']))); ?></span>
                    </div>
                    <textarea name="finalreport" id="finalreport" cols="50" rows="20" class="form-control mt-3 mb-3 text-black" value=''></textarea>
                    <input type="submit" class="btn btn-primary mb-5 float-left" value="submit">
                </form>
            </div>
        </div>
    </div> 
      
    <?php $__env->stopSection(); ?>


<script>
    var text=document.getElementById('finalreport').value;
    var sugg=document.getElementsByClassName('sugg');
    for(var s of sugg){
        s.addEventListener('click',function(){
            var myTextArea = document.querySelector('#finalreport');
            myTextArea.val(myTextArea.value + ' '+this.innerText);
            console.log(myTextArea.value);
        });
    }

    
</script> 
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/doctor/changepatstate.blade.php ENDPATH**/ ?>