

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href=<?php echo e(asset('css/checkbox.css')); ?>>
<div class="container p-2 " style="background-image: linear-gradient(to right ,#0044ee88,#0e444499)">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center mb-2 font-weight-bolder p-2 bg-secondary text-white">
              <p  style="font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; font-size:30px">Date to day  { <?php echo e(date('Y-m-d')); ?> }</p>
            </div>
            <div class="card p-3 ">
               
                <form method="POST" action=<?php echo e(route('savesymp')); ?> >
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $syms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   

                <fieldset>
                    <label>
                      <input type="checkbox" name="symp[<?php echo e($s['symp_deg']); ?>][]" value="<?php echo e($s['id']); ?>" />
                      <span><?php echo e($s['title']); ?></span>
                    </label>
                  </fieldset>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <textarea required style="color:rgb(55, 52, 255)" name="dayreport" id="" class="w-75 ml-4 form-control " cols="30" rows="10" placeholder="daily report
how are you feeling to day
is there a Strange symptoms ?">
                    </textarea>
                    <div class="rounded text-center mb-2 font-weight-bolder mt-2 bg-light" style="border :2px solid #ddd" >
                        <input type="submit" class="btn btn-primary m-3 w-25 " />
                        <a href="/" class="btn btn-secondary m-3 w-25">cancel</a> 
                    </div>
                </form>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/symp/inssymp.blade.php ENDPATH**/ ?>