<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/patientprof.css')); ?>" rel="stylesheet">
    <div class="jumbotron header m-1" >
<br><br>
        <?php if(isset($mydoctor['image'])): ?>
        <img class="pimage headerimg"  src="storage/<?php echo e($mydoctor['image']); ?>" alt=""/>
        <?php else: ?>
        <img  class="headerimg" src=<?php echo e(asset('mp/anon.png')); ?> alt=""/>
        <?php endif; ?>
    </div>

<div class=" text-center card m-5 bg-secondary text-white">
    
<div class="row p-3 ">
        <div class="col-4">
        Doctor name : <?php echo e($mydoctor['name']); ?>

    </div>
    <div class="col-4">
            Doctor phone : <a href="tel:+<?php echo e($mydoctor['phone']); ?>"><?php echo e($mydoctor['phone']); ?></a>
    </div>
    <div class="col-4">
            Doctor email : <a href="mailto:<?php echo e($mydoctor['email']); ?>"><?php echo e($mydoctor['email']); ?></a>
    </div>
    <hr class="white_hr mt-5">
</div>
    
<div class="row p-3 ">
    <div class="col-4">
        Country : <?php echo e($mydoctor['country']); ?>

    </div>
    <div class="col-4">
        City : <?php echo e($mydoctor['city']); ?>

    </div>
    <div class="col-4">
        work time start/end : (<?php echo e($mydoctor['startwork']); ?>/<?php echo e($mydoctor['endwork']); ?>)
    </div>

</div>
<div class="row p-3 ">
    <div class="col-12">
        <div class="text-center text-capitalize m-2 text-success bg-light rounded w-25 m-auto">description</div>
    <div class="bg-info p-2 mt-2 rounded"> <?php echo e($mydoctor['description']); ?></div>
    </div>
</div>
</div>

  <div class="alert alert-success w-25 position-fixed d-none" style="z-index: 10;display: none;top:5%;left:2%" id="success-alert formModal">
    
    <strong>Success! </strong> email sent successfully.
  </div>
<div class="container mt-5 w-100">
  <div class="modal-body mt-4 w-100">
    <form id="myForm" name="myForm" action="<?php echo e(route('maildoc')); ?>" method="POST"  class="form-horizontal" novalidate="" >
        <?php echo csrf_field(); ?>
        
            <legend >Send Message Doctor <?php echo e($mydoctor['name']); ?></legend>
            <textarea name="emailtodoc" id="emailtodoc" cols="60" rows="7" class="form-control w-100 "></textarea>
       
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" id="btn-save" value="add">Send Message
            </button>
        </div>
    </form>
</div>
</div>
<div class="container ">
<?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($item['sender']===1): ?>
<li class="list-group bg-info m-1 p-1 w-50 text-light border position-relative mb-5"><?php echo e($item['message']); ?><span class="bg-dark rounded text-center mt-1 w-25 p-1 position-absolute " style='font-size: 10px;right:10px;bottom:-25px'><?php echo e(date('M-d ~ h:m',strtotime($item['created_at']))); ?></span></li>
<?php else: ?>
<li class="list-group bg-success m-1 p-1 w-50 text-light float-right border position-relative mb-5"><?php echo e($item['message']); ?><span class="bg-dark rounded  text-center mt-1 w-25 p-1 position-absolute" style='font-size: 10px;right:10px;bottom:-25px'><?php echo e(date('M-d ~ h:m',strtotime($item['created_at']))); ?></span></li>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/mydoctor.blade.php ENDPATH**/ ?>