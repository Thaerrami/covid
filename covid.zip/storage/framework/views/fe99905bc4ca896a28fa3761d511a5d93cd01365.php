

<?php $__env->startSection('content'); ?>


<!------ Include the above in your HEAD tag ---------->

<?php $__env->startPush('head'); ?>
<!-- Styles -->
<link rel="stylesheet" href=<?php echo e(asset('css/phome.css')); ?>>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php $__env->stopPush(); ?>


<div class="container emp-profile pcb mt-5 bg-white p-3 " style='border-radius:20px'>
                <div class="row ">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <img  class='pimage'
                            src="<?php echo e(asset( $image!==''? "storage/$image":'mp/anon.png')); ?>" alt="no image"/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5>
                                        <?php echo e($name); ?>

                                    </h5>
                                    <p class="proile-rating">status : <span><?php echo e($status); ?></span></p>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">State info</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                   
                </div>
                <div class="row mt-3">

                    <div class="col-md-4">
                        <?php if($current==='Case'): ?>
                        <?php if($filled): ?>
                        
                            <div class='text-center'>
                                <h1><img id="editableimage2" src="<?php echo e(asset('mp/inserted.gif')); ?>" width="300px" alt="sending a hug gifs get the best gif on giphy"/></h1>
                                <h4>Data insterted to day</h4>
                            </div>
                            
                        <?php else: ?>
                        <button class='text-center btn btn-outline-primary ml-4 mt-5' id='fillbut' style='margin:auto; text-decoration:none;;margin-top:20px' 
                        
                        ><h3>Fill patient data</h3></button>
                        <?php endif; ?>
                        <?php endif; ?>
                        
                    </div>
                    <div class="col-md-8">
                        <?php if($current==='Case'): ?>
                        <a href="/doc/changepatstate/<?php echo e($id); ?>" class="d-inline-flex btn btn-primary mb-2 border" >change status (<p class="text-dark">recover</p>&nbsp; /&nbsp; <p class="text-danger">death</p>)</a>
                        <?php elseif($current==='Recovered'): ?>

                        <form  method="POST" class="form-group btn-submit " style="text-align: left" id="formupdate">
                            <?php echo csrf_field(); ?> 
                        <input type="hidden" name="id" id='id' data-id=<?php echo e($id); ?> />
                        <input type="submit" name="submit" id="submit"  class="btn btn-primary float-left mt-1" value="reassign as patient" />
                      </form><br><br>
                      <?php else: ?>
                        <?php endif; ?>
                        
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Name</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($name); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Email</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($email); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Phone</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($phone); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>country</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($country); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>city</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($city); ?></p>
                                            </div>
                                        </div>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>status</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($status); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>current state</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($current); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>logged in</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($start); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Birth Of Date</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo e($bof); ?></p>
                                            </div>
                                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            
             
                 <hr style="border:1px solid rgb(112, 112, 112) ; border-radius:50%">
                
                 <h2 class="text-center m-5 rounded bg-info p-2 text-white"> Patient Reports 
                     <img src="https://img.icons8.com/nolan/64/business-report.png"/>
                </h2>

                <?php if(isset($finalreport)): ?>
                
                <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Date</th>
                        <th scope="col">final report</th>
                      </tr>
                    </thead>
                    <tbody>
                     <tr>
                        <td><?php echo e($finalreport['date']); ?></td>
                        <td><?php echo e($finalreport['recoverreport']??$finalreport['deathreport']); ?></td>
                      </tr>   
                     </tbody>
                  </table>
                  <?php endif; ?>
                
                 <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">Date</th>
                        <th scope="col">report</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                     <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($item['date']); ?></td>
                        <td><?php echo e($item['report']); ?></td>
                      </tr>   
                     
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

        </div>

        <?php $__env->startPush('headhome'); ?>
<!-- Styles -->
<!-- Scripts -->

<?php $__env->stopPush(); ?>
<div class="filerpoper">
    
<div class="card p-3">
    <span class="cls-btn">X</span>     
    <form method="POST" id="form" action=<?php echo e(route('docsavesymp')); ?> >
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $syms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       

    <fieldset>
        <label>
          <input type="checkbox" name="symp[]" data-sympdeg="<?php echo e($s['symp_deg']); ?>" value="<?php echo e($s['id']); ?>" />
          <span><?php echo e($s['title']); ?></span>
        </label>
      </fieldset>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <textarea required style="color:rgb(55, 52, 255)" name="dayreport" id="" class="w-75 ml-4 form-control " cols="30" rows="10" placeholder="daily report
how are you feeling to day
is there a Strange symptoms ?">
        </textarea>
        <div class="rounded text-center mb-2 font-weight-bolder mt-2 bg-light" style="border :2px solid #ddd" >
            <input type="hidden" name='id' id='id' value=<?php echo e($id); ?>>
            <button type="submit" id='hi' class="btn btn-primary w-100">Submit</button>
        </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
</script>
<script type='text/javascript'>

$(document).ready(()=>{
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

$('#formupdate').on('submit', function(event){
        event.preventDefault();
        var id=$('#id').data('id');
        var url = '/doc/reassign';

        $.ajax({
            url:url,
            method:"POST",
            data:{
                id:id
                , _token: '<?php echo e(csrf_token()); ?>'
            },
            success:function(data)
            {
                alert(data);
                window.location.reload();
            },
            error: function (data, textStatus, errorThrown) {
                alert(data);

    }
        })


    });

///////////fill symp

$('.filerpoper').hide(10);

$('.cls-btn').click(()=>{
    $('.filerpoper').hide(1000);
});

$('#fillbut').click(()=>{
    $('.filerpoper').show(500);
});

        var symps=[];
        var url='/doc/docsavesymp';
        var dayreport='';
        var id;
        var sympdeg=[];

        $( "#form" ).submit(function( event ) {
            event.preventDefault();
            $('#hi').prop('disabled',true);
            $('input:checked').each(function(){
                sympdeg.push($(this).data('sympdeg'));
            });

            dayreport=$("textarea[name='dayreport']").val() ??'nothing to day';
            id=$('#id').val();

            $("input:checked").each(function(){ 
                symps.push(this.value);
            });

            sympdeg=Math.max(...sympdeg);
            symps=JSON.stringify(symps);
            

    $.ajax({
        method:'POST',
        url:url,
        data:{
            _token:'<?php echo e(csrf_token()); ?>',
            symps:symps,
            sympdeg:sympdeg,
            dayreport:dayreport,
            id:id
        },
        success:(data)=>{
            alert(data);
            window.location.reload();
        },
        error:(data)=>{
            console.log(data)
        }
    })    

});
  




})


</script>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/doctor/showonepat.blade.php ENDPATH**/ ?>