

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/patientprof.css')); ?>" rel="stylesheet">

</div>
</div>
<div class="container m-5">
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="list-group bg-success m-1 p-1 w-75 text-light  border position-relative mb-3"><span>
    
        <img width="40" height="40" class="border mr-1 ml-1" style="border-radius:50%" src=<?php echo e(asset($item->uimg != ''? "storage/".$item->uimg:'mp/anon.png')); ?>  alt="no image">

    &nbsp;<?php echo e($item->uname); ?></span><?php echo e($item->message); ?><span class="bg-secondary rounded  text-center mt-1 w-25 p-1 position-absolute" style='font-size: 10px;right:3px;bottom:1px'><?php echo e(date('M-d ~ h:m',strtotime($item->created_at))); ?></span>
    <span>reply &#x2937;</span>
   <form action="<?php echo e(route('doc.reply',[
       'pat_id'=>$item->Patient_id,
       'qus_id'=>$item->id
   ])); ?>" method="POST"><?php echo csrf_field(); ?> <div class=''><input type="text" name="reply" id="" class="form-control h-25"></div><button type="submit" class="btn btn-sm btn-primary mt-1 " style="width:20%; "> send</button></form></form>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/doctor/docmessages.blade.php ENDPATH**/ ?>