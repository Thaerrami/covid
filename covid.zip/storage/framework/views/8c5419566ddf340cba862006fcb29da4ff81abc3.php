


<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php if(isset($symp)): ?>
        <?php $__currentLoopData = $symp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-2 m-3 bg-light rounded row">
        <div class="w-100"><?php echo e($key); ?></div>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ml-3 p-2 m-2 rounded col-3" style="background: rgb(218, 218, 218)"><?php echo e($s); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
       
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/mysymp.blade.php ENDPATH**/ ?>