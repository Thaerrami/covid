
<?php $__env->startSection('content'); ?>
<div class="bg-light p-3 d-flex justify-content-around">
    <span class="btn"><a href="route('/')">back</a></span>
    <span class="btn"><a href="route('/')">home</a></span>
    <span class="btn"><a href="route('/')">help</a></span>
    <span class="btn"><a href="route('/')">Public Consultaion & chat</a></span>
    <span class="btn"><a href="route('/')">about us </a></span>
</div>
    <div class="container">
        awef
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/help.blade.php ENDPATH**/ ?>