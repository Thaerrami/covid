


<?php $__env->startSection('content'); ?>
<form  method="POST" id="submit">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col">
          <div class="form-group">
            <label>country</label>
            <select class="form-control" type="text" name='country' value=<?php echo e(Auth::user()->country); ?> required  id="country">
              <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option  value="<?php echo e($item['name']); ?>" <?php echo e($item['name']==Auth::user()->country?'selected':null); ?>><?php echo e($item['name']); ?></option> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <div class="form-group">
            <label>city</label>
            <input class="form-control" type="text" name='city' id="city" minlength="6" required value=<?php echo e(Auth::user()->city); ?> placeholder=<?php echo e(Auth::user()->city); ?>>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col d-flex justify-content-end">
          <button class="btn btn-primary" type="submit">Save Changes</button>
        </div>
      </div>

</form>


<script>

  $("#submit").on('submit',(e)=>{
    e.preventDefault();
  
    var country = $('#country').val();
    var city = $('#city').val();
   
    
       $.ajax({
         method:'POST',
         url:"./edituserprofile",
         data:{
            _token: '<?php echo e(csrf_token()); ?>',
            country:country,
            city:city
         },
         success:(data)=>{
           alert('location updated successfuly');
         },
         error:(error)=>{
           console.log(error)
         }
       }
     )
     
    });
       
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.editprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/location.blade.php ENDPATH**/ ?>