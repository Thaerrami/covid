


<?php $__env->startSection('content'); ?>
<form id="submit" method="POST">
    <?php echo csrf_field(); ?>
<div class="row">                  
    <div class="col">
      <div class="form-group">
        <label>Username</label>
        <input class="form-control" required type="text" name="username" id="username" placeholder=<?php echo e(Auth::user()->name); ?> value=<?php echo e(Auth::user()->name); ?> >
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col d-flex justify-content-end">
      <button class="btn btn-primary" type="submit">Save Changes</button>
    </div>
  </div>
</form>


<script>

  $("#submit").on('submit',(e)=>{
    e.preventDefault();
  
    var username = $('#username').val();

    
       $.ajax({
         method:'POST',
         url:"./edituserprofile",
         data:{
            _token: '<?php echo e(csrf_token()); ?>',
            username:username,
         },
         success:(data)=>{
           alert('username successfuly updated');
         },
         error:(error)=>{
           console.log(error)
         }
       }
     )
     
    });
       
      </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('patient.editprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\php\www\covid\resources\views/patient/peditname.blade.php ENDPATH**/ ?>