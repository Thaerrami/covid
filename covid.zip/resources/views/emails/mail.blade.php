Hello <strong>{{ $name }}</strong>,
<p>{{$body}}</p>
<div><a href="http://localhost:8000/">http://localhost:8000/</a></div>