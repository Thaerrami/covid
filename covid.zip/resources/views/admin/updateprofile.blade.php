@foreach ($data as $item)
    {{$item}}<br>
@endforeach